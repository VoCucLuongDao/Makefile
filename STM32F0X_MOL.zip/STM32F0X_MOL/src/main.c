
#include "stm32f0xx.h"

void main(){
  
  while(1){
    
  }
}
